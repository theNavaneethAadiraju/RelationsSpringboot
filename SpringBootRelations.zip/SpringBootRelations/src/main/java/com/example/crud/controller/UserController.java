package com.example.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.crud.model.Person;
import com.example.crud.service.UserService;

@RestController
@RequestMapping("/personsinfo")
public class UserController {

	@Autowired
	private UserService userservice;
	
	@PostMapping("/saveperson")
	public Person saveperson(Person person) {
		return userservice.savePerson(person);
	}
	
	@GetMapping("/getpersons")
	public List<Person> getAllPersons() {
		return userservice.getAllPersons();
	}
	
	
}
