package com.example.crud.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.crud.model.Person;

public interface PersonRepo extends JpaRepository<Person, Long>{

}
