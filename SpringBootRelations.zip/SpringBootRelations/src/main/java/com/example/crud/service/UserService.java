package com.example.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.crud.model.Person;
import com.example.crud.repo.PersonRepo;

@Service
public class UserService {
	
	@Autowired
	private PersonRepo repo;
	
	public Person savePerson(Person person) {
		return repo.save(person);
	}
	
	
	public List<Person> getAllPersons(){
		return repo.findAll();
	}
	

}
